C = {"CR": "Credit Event", "MA": "Macroeconomic", "GE": "Geopolitical", "RL": "Regulatory/Legal", "MN": "Merger/Acquisition",
     "EG": "Earnings/Guidance", "MC": "Management Change", "PL": "Product Launch", "OP": "Operational/Supply Chain",
     "ES": "ESG/Climate", "CY": "Cyber/Technology Risk", "OT": "Other/Non-event"}
S = {"n": "negative", "u": "neutral", "p": "positive", "-": "-"}
