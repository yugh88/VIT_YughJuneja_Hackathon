import sys
import pandas as pd
from merge import read
name, src, textcol = sys.argv[1], sys.argv[2], sys.argv[3]
p1, p2, adj = read(f"p1_{name}.raw"), read(f"p2_{name}.raw"), read(f"adjudication_{name.split('_')[0]}.raw")
d = pd.read_csv(src)
ev, se, why, flag = [], [], [], []
for rid in d["id"]:
    if rid in adj:
        e, s, w = adj[rid]; f = "yes"
        if s == "-" and p1[rid][1] != "-":  # adjudication of event only keeps agreed sentiment
            s = p1[rid][1] if p1[rid][1] == p2[rid][1] else s
    else:
        assert p1[rid][:2] == p2[rid][:2], rid
        e, s, w = p1[rid]; f = "no"
    ev.append(e); se.append(s); why.append(w); flag.append(f)
d["event_label"] = ev
if se[0] != "-":
    d["sentiment_label"] = se
d["rationale"], d["adjudicated"] = why, flag
out = src.replace("_to_label.csv", "_labelled.csv")
d.to_csv(out, index=False)
print(out, len(d), d["event_label"].value_counts().to_dict())
