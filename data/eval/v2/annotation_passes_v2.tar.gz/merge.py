import sys, re
from collections import Counter
sys.path.insert(0, ".")
from codes import C, S

def read(f):
    out = {}
    for ln in open(f, encoding="utf-8"):
        ln = ln.rstrip("\n")
        if not ln.strip():
            continue
        m = re.match(r"(\S+) (\S+) (\S+) (.*)", ln)
        rid, ev, se, why = m.groups()
        out[rid] = (C[ev], S[se], why)
    return out

def kappa(a, b):
    n = len(a); po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] * cb[k] for k in set(a) | set(b)) / n / n
    return (po - pe) / (1 - pe) if pe < 1 else 1.0

if __name__ == "__main__":
    name = sys.argv[1]
    p1, p2 = read(f"p1_{name}.raw"), read(f"p2_{name}.raw")
    assert set(p1) == set(p2), set(p1) ^ set(p2)
    ids = sorted(p1)
    print(name, "n", len(ids), "event kappa %.3f" % kappa([p1[i][0] for i in ids], [p2[i][0] for i in ids]))
    if p1[ids[0]][1] != "-":
        print("sentiment kappa %.3f" % kappa([p1[i][1] for i in ids], [p2[i][1] for i in ids]))
    for i in ids:
        if p1[i][:2] != p2[i][:2]:
            print(i, "|", p1[i][0], p1[i][1], "|", p2[i][0], p2[i][1], "|", p1[i][2], "/", p2[i][2])
